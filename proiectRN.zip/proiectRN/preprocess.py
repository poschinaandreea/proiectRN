import pandas as pd
import os
from sklearn.model_selection import train_test_split

RAW_PATH = "data/raw/data_simulated.csv"
PROCESSED_PATH = "data/processed/"

def preprocess_data():

    os.makedirs(PROCESSED_PATH + "train", exist_ok=True)
    os.makedirs(PROCESSED_PATH + "validation", exist_ok=True)
    os.makedirs(PROCESSED_PATH + "test", exist_ok=True)

    df = pd.read_csv(RAW_PATH)

    # Amestecăm datele
    df = df.sample(frac=1, random_state=42).reset_index(drop=True)

    # Împărțire train/validation/test
    train_df, temp_df = train_test_split(df, test_size=0.3, random_state=42)
    val_df, test_df = train_test_split(temp_df, test_size=0.5, random_state=42)

    # Salvare
    train_df.to_csv(PROCESSED_PATH + "train/train.csv", index=False)
    val_df.to_csv(PROCESSED_PATH + "validation/validation.csv", index=False)
    test_df.to_csv(PROCESSED_PATH + "test/test.csv", index=False)

    print("Date procesate și salvate în folderele train/validation/test")

if __name__ == "__main__":
    preprocess_data()
