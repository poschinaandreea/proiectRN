import cv2
import joblib
import pandas as pd
import numpy as np
import time
import os

# --- Căi și Constante ---
# Schimbați 'video_test.mp4' cu numele fișierului dumneavoastră real, dacă este necesar
VIDEO_PATH = 'video_test.mp4'
MODEL_PATH = 'models/suspicion_detector_model.pkl'

# Calea către fișierul Haar Cascade pentru detecția fețelor (parte din instalarea OpenCV)
FACE_CASCADE_PATH = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'

# Nivelul sub care considerăm că mișcarea este nesemnificativă (pentru a calcula durata)
IMMOBILITY_THRESHOLD = 0.05
# Câți pixeli pe cadru reprezintă mișcare mare (pentru normalizare)
MOVEMENT_NORMALIZATION_FACTOR = 50

# --- Variabile Globale de Monitorizare a Comportamentului ---
# Acestea urmăresc starea comportamentului pe parcursul cadrelor
last_face_center = None
immobility_start_time = time.time()


def calculate_features(face_box, current_time):
    """
    Calculează caracteristicile necesare pentru modelul ML: 'durata_sec' și 'miscare'.
    """
    global last_face_center, immobility_start_time

    x, y, w, h = face_box
    current_center = (x + w // 2, y + h // 2)

    # Valori implicite
    miscare_score = 0.0
    immobility_duration = 0.0

    # 1. Calculul Mișcării
    if last_face_center is not None:
        # Distanța euclidiană (în pixeli) între centrul feței din cadru curent și cel anterior
        distance = np.sqrt(
            (current_center[0] - last_face_center[0]) ** 2 +
            (current_center[1] - last_face_center[1]) ** 2
        )
        # Normalizarea distanței pentru a obține 'miscare' între 0 și 1
        miscare_score = min(distance / MOVEMENT_NORMALIZATION_FACTOR, 1.0)

    # 2. Calculul Duratei Imobilității (durata_sec)
    if miscare_score < IMMOBILITY_THRESHOLD:
        # Dacă mișcarea este sub prag, actualizăm durata imobilității
        immobility_duration = current_time - immobility_start_time
    else:
        # Dacă mișcarea este suficient de mare, resetăm cronometrul
        immobility_start_time = current_time
        immobility_duration = 0.0

    # Actualizăm poziția centrului pentru următorul cadru
    last_face_center = current_center

    return immobility_duration, miscare_score


def run_video_detection():
    # 1. Încărcarea Modelului ML și a Detectoarelor OpenCV
    try:
        model = joblib.load(MODEL_PATH)
    except FileNotFoundError:
        print(f"Eroare: Modelul ML nu a fost găsit la {MODEL_PATH}. Vă rugăm rulați python train_model.py.")
        return

    face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)
    if face_cascade.empty():
        print("Eroare: Nu s-a putut încărca fișierul Haar Cascade. Verificați instalarea OpenCV.")
        return

    # 2. Citirea Video
    cap = cv2.VideoCapture(VIDEO_PATH)
    if not cap.isOpened():
        print(f"Eroare: Nu s-a putut deschide videoclipul la calea {VIDEO_PATH}. Asigurați-vă că fișierul există.")
        return

    print("--- Începe Detecția Comportamentului Video ---")

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        current_time = time.time()

        # Procesarea imaginii
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detecția Fețelor
        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(50, 50)
        )

        # 3. Analiza pe Fiecare Față Detectată
        for (x, y, w, h) in faces:

            # Calculul Caracteristicilor
            durata, miscare = calculate_features((x, y, w, h), current_time)

            # Pregătirea inputului pentru modelul ML
            input_data = pd.DataFrame({
                'durata_sec': [durata],
                'miscare': [miscare]
            })

            # Aplicarea Modelului ML
            prediction = model.predict(input_data)[0]

            # 4. Afișare Rezultat pe Cadru
            color = (0, 255, 0)  # Verde = Normal
            label = "NORMAL"

            if prediction == 1:
                color = (0, 0, 255)  # Roșu = Suspect
                label = "SUSPECT"

            # Desenează dreptunghiul (Bounding Box)
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)

            # Afișează label-ul și durata
            text_label = f"{label} | Durata: {durata:.1f}s | Miscare: {miscare:.2f}"
            cv2.putText(frame, text_label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

            # Logica de suspiciune din modelul nostru este:
            # SUSPECT daca: Durata > 10 sec UNDE Miscare < 0.2 (aproximativ)

        # 5. Afișează Fereastra Video
        cv2.imshow('Detectie Comportament Suspect', frame)

        # Apăsați 'q' pentru a ieși
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Curățenie la final
    cap.release()
    cv2.destroyAllWindows()
    print("Detectie Video finalizată.")


if __name__ == "__main__":
    run_video_detection()