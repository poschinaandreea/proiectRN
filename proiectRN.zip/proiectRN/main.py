import joblib
import pandas as pd
import numpy as np
import os

MODEL_PATH = "models/suspicion_detector_model.pkl"


def predict_new_case(durata_sec, miscare):
    """
    Încarcă modelul salvat și face o predicție pentru un singur caz nou.
    """

    # 1. Încărcarea Modelului
    if not os.path.exists(MODEL_PATH):
        print(f"Eroare: Modelul nu a fost găsit la calea {MODEL_PATH}")
        print("Asigurați-vă că ați rulat python train_model.py înainte.")
        return

    # joblib.load încarcă modelul din fișierul .pkl
    model = joblib.load(MODEL_PATH)
    print("Modelul de detectare a suspiciunii a fost încărcat cu succes.")

    # 2. Pregătirea Datelor Noi
    # Modelul așteaptă datele în format DataFrame (tabel) cu aceleași coloane
    new_data = pd.DataFrame({
        'durata_sec': [durata_sec],
        'miscare': [miscare]
    })

    print(f"\nCazul de analizat: Durata={durata_sec}s, Mișcare={miscare}")

    # 3. Prezicerea
    prediction = model.predict(new_data)[0]

    # 4. Afișarea Rezultatului
    if prediction == 1:
        result = "SUSPICIOS"
    else:
        result = "NORMAL"

    print(f"\n--- REZULTAT PREDICTIE ---")
    print(f"Modelul clasifică acest comportament ca: **{result}** (Cod {prediction})")

    # Afișăm și probabilitatea, pentru o analiză mai fină
    probabilities = model.predict_proba(new_data)[0]
    print(f"Probabilitatea de a fi NORMAL (0): {probabilities[0] * 100:.2f}%")
    print(f"Probabilitatea de a fi SUSPECT (1): {probabilities[1] * 100:.2f}%")


if __name__ == "__main__":
    # EXEMPLU DE CAZ NOU:
    # 1. Durată Mare (15 sec) ȘI Mișcare Mică (0.1) -> Ar trebui să fie Suspect (1)
    # 2. Durată Mică (5 sec) ȘI Mișcare Mare (0.8) -> Ar trebui să fie Normal (0)

    print("Testul 1: Caz evident SUSPICIOS")
    predict_new_case(durata_sec=15.0, miscare=0.1)

    print("\n------------------------------")

    print("Testul 2: Caz evident NORMAL")
    predict_new_case(durata_sec=5.0, miscare=0.8)


