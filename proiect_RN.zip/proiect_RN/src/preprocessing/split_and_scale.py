import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from config.config import (
    RAW_CSV, PROCESSED_CSV,
    DATA_PROCESSED_DIR, DATA_TRAIN_DIR, DATA_VAL_DIR, DATA_TEST_DIR,
    MODELS_DIR, SCALER_PATH,
    FEATURES, LABEL_COL,
    TEST_SIZE, VAL_SIZE, RANDOM_SEED
)

def save_split(folder, X, y):
    folder.mkdir(parents=True, exist_ok=True)
    np.save(folder / "X.npy", X)
    np.save(folder / "y.npy", y)

def main():
    # 1. Load raw data
    df = pd.read_csv(RAW_CSV)

    X = df[FEATURES].to_numpy()
    y = df[LABEL_COL].to_numpy()

    # 2. Split train+val vs test
    X_trainval, X_test, y_trainval, y_test = train_test_split(
        X, y,
        test_size=TEST_SIZE,
        random_state=RANDOM_SEED,
        stratify=y
    )

    # 3. Split train vs validation
    X_train, X_val, y_train, y_val = train_test_split(
        X_trainval, y_trainval,
        test_size=VAL_SIZE,
        random_state=RANDOM_SEED,
        stratify=y_trainval
    )

    # 4. Scaling
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_val_s = scaler.transform(X_val)
    X_test_s = scaler.transform(X_test)

    # 5. Save scaler
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(scaler, SCALER_PATH)

    # 6. Save splits
    save_split(DATA_TRAIN_DIR, X_train_s, y_train)
    save_split(DATA_VAL_DIR, X_val_s, y_val)
    save_split(DATA_TEST_DIR, X_test_s, y_test)

    # 7. Save processed CSV (optional, useful for docs)
    DATA_PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(PROCESSED_CSV, index=False)

    print("Preprocessing completed:")
    print(f" Train size: {len(y_train)}")
    print(f" Validation size: {len(y_val)}")
    print(f" Test size: {len(y_test)}")

if __name__ == "__main__":
    main()
