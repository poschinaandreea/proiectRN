import numpy as np
import matplotlib.pyplot as plt
import joblib
import tensorflow as tf
from pathlib import Path
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    f1_score,
    accuracy_score
)

from config.config import (
    DATA_TEST_DIR,
    BASELINE_MODEL_PATH,
    MLP_MODEL_PATH,
    RESULTS_FIG_DIR,
    THRESHOLD
)

def eval_baseline(X_test, y_test):
    model = joblib.load(BASELINE_MODEL_PATH)
    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    print("=== Baseline: Logistic Regression (TEST) ===")
    print(f"Accuracy: {acc:.3f} | F1: {f1:.3f}")
    print(classification_report(y_test, y_pred))

    return y_pred

def eval_mlp(X_test, y_test, threshold=THRESHOLD):
    model = tf.keras.models.load_model(MLP_MODEL_PATH)
    probs = model.predict(X_test, verbose=0).ravel()
    y_pred = (probs >= threshold).astype(int)

    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)

    print("=== MLP (TEST) ===")
    print(f"Threshold: {threshold:.2f}")
    print(f"Accuracy: {acc:.3f} | F1: {f1:.3f}")
    print(classification_report(y_test, y_pred))

    return y_pred

def save_confusion_matrix(y_true, y_pred, title, filename):
    cm = confusion_matrix(y_true, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm)
    disp.plot()
    plt.title(title)

    RESULTS_FIG_DIR.mkdir(parents=True, exist_ok=True)
    plt.savefig(RESULTS_FIG_DIR / filename)
    plt.close()  # IMPORTANT: nu mai blocam executia

def main():
    X_test = np.load(DATA_TEST_DIR / "X.npy")
    y_test = np.load(DATA_TEST_DIR / "y.npy")

    # Baseline (daca exista)
    if Path(BASELINE_MODEL_PATH).exists():
        y_pred_baseline = eval_baseline(X_test, y_test)
        save_confusion_matrix(
            y_test,
            y_pred_baseline,
            "Confusion Matrix - Baseline (LogReg)",
            "cm_baseline.png"
        )
        print()
    else:
        print("Baseline model not found -> skipping baseline evaluation.")

    # MLP
    y_pred_mlp = eval_mlp(X_test, y_test)
    save_confusion_matrix(
        y_test,
        y_pred_mlp,
        "Confusion Matrix - MLP",
        "cm_mlp.png"
    )

if __name__ == "__main__":
    main()
