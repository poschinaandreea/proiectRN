import numpy as np
import joblib
import tensorflow as tf

from config.config import SCALER_PATH, MLP_MODEL_PATH, FEATURES, THRESHOLD

def main():
    # Exemplu "manual" (în ordinea FEATURES)
    # avg_speed, stop_time, direction_changes, path_irregularity, time_of_day, distance
    sample = {
        "avg_speed": 0.6,
        "stop_time": 35.0,
        "direction_changes": 10,
        "path_irregularity": 1.2,
        "time_of_day": 2,
        "distance": 20.0
    }

    x = np.array([[sample[f] for f in FEATURES]], dtype=float)

    scaler = joblib.load(SCALER_PATH)
    x_s = scaler.transform(x)

    model = tf.keras.models.load_model(MLP_MODEL_PATH)
    prob = float(model.predict(x_s, verbose=0).ravel()[0])
    pred = 1 if prob >= THRESHOLD else 0

    print("Input sample:", sample)
    print(f"Probabilitate clasa 1: {prob:.3f}")
    print("Predictie:", "SUSPECT (1)" if pred == 1 else "NORMAL (0)")

if __name__ == "__main__":
    main()
