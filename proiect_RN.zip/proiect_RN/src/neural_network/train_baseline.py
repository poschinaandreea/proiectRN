import numpy as np
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

from config.config import (
    DATA_TRAIN_DIR, DATA_VAL_DIR,
    MODELS_DIR, BASELINE_MODEL_PATH,
    RANDOM_SEED
)

def main():
    # Diagnostic: unde salveaza
    print("MODELS_DIR =", MODELS_DIR)
    print("BASELINE_MODEL_PATH =", BASELINE_MODEL_PATH)

    # Load train / validation
    X_train = np.load(DATA_TRAIN_DIR / "X.npy")
    y_train = np.load(DATA_TRAIN_DIR / "y.npy")

    X_val = np.load(DATA_VAL_DIR / "X.npy")
    y_val = np.load(DATA_VAL_DIR / "y.npy")

    # Train baseline model
    model = LogisticRegression(max_iter=2000, random_state=RANDOM_SEED)
    model.fit(X_train, y_train)

    # Evaluate on validation
    y_pred = model.predict(X_val)
    print("=== Baseline: Logistic Regression (Validation) ===")
    print(classification_report(y_val, y_pred))

    # Save model
    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, BASELINE_MODEL_PATH)

    print("Saved baseline model to:", BASELINE_MODEL_PATH)

if __name__ == "__main__":
    main()
