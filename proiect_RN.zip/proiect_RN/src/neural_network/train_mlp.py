import numpy as np
import tensorflow as tf
from tensorflow import keras
from pathlib import Path

from config.config import (
    DATA_TRAIN_DIR, DATA_VAL_DIR,
    MODELS_DIR, MLP_MODEL_PATH,
    RANDOM_SEED
)

def main():
    tf.keras.utils.set_random_seed(RANDOM_SEED)

    print("ROOT/MODEL PATH CHECK")
    print("MODELS_DIR =", MODELS_DIR)
    print("MLP_MODEL_PATH =", MLP_MODEL_PATH)

    Path(MODELS_DIR).mkdir(parents=True, exist_ok=True)

    X_train = np.load(DATA_TRAIN_DIR / "X.npy")
    y_train = np.load(DATA_TRAIN_DIR / "y.npy")
    X_val = np.load(DATA_VAL_DIR / "X.npy")
    y_val = np.load(DATA_VAL_DIR / "y.npy")

    model = keras.Sequential([
        keras.layers.Input(shape=(X_train.shape[1],)),
        keras.layers.Dense(32, activation="relu"),
        keras.layers.Dense(16, activation="relu"),
        keras.layers.Dense(1, activation="sigmoid")
    ])

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy"]
    )

    model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=2,          # doar 2 epoci pentru test
        batch_size=64,
        verbose=1
    )

    save_path = Path(MLP_MODEL_PATH).resolve()
    print("Saving to:", save_path)

    model.save(str(save_path))
    print("Saved. Exists now?", save_path.exists())

if __name__ == "__main__":
    main()
