from pathlib import Path
from config.config import ROOT, MODELS_DIR, MLP_MODEL_PATH

def main():
    print("ROOT =", ROOT)
    print("MODELS_DIR =", MODELS_DIR)
    print("MLP_MODEL_PATH =", MLP_MODEL_PATH)

    Path(MODELS_DIR).mkdir(parents=True, exist_ok=True)

    test_file = Path(MODELS_DIR) / "write_test.txt"
    test_file.write_text("ok", encoding="utf-8")

    print("Created:", test_file)
    print("Exists?", test_file.exists())

if __name__ == "__main__":
    main()
