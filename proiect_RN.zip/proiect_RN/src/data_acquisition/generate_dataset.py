import numpy as np
import pandas as pd

from config.config import (
    N_SAMPLES, RANDOM_SEED, LABEL_NOISE,
    DATA_RAW_DIR, RAW_CSV
)

def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1 / (1 + np.exp(-x))

def generate(n: int = N_SAMPLES, seed: int = RANDOM_SEED) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    avg_speed = rng.normal(loc=1.2, scale=0.35, size=n).clip(0, None)     # m/s
    stop_time = rng.gamma(shape=2.0, scale=8.0, size=n)                   # sec
    direction_changes = rng.poisson(lam=6, size=n)                        # count
    path_irregularity = rng.normal(loc=0.0, scale=1.0, size=n)            # z
    time_of_day = rng.integers(0, 24, size=n)                             # hour

    distance = (avg_speed * (60 - np.tanh(stop_time / 30) * 20) + rng.normal(0, 5, n)).clip(0, None)

    # corelatie: stop_time mai mare -> avg_speed mai mica
    avg_speed = (avg_speed - 0.02 * stop_time).clip(0, None)

    # scor probabilistic
    z = (
        0.18 * stop_time
        - 1.5 * avg_speed
        + 0.35 * path_irregularity
        + 0.08 * direction_changes
        + 0.02 * (np.abs(time_of_day - 2))
        - 0.004 * distance
    )

    p = sigmoid(z)
    label = rng.binomial(1, p)

    # noise: flip eticheta cu prob mica
    flips = rng.random(n) < LABEL_NOISE
    label = np.where(flips, 1 - label, label)

    return pd.DataFrame({
        "avg_speed": avg_speed,
        "stop_time": stop_time,
        "direction_changes": direction_changes,
        "path_irregularity": path_irregularity,
        "time_of_day": time_of_day,
        "distance": distance,
        "label": label
    })

def main():
    DATA_RAW_DIR.mkdir(parents=True, exist_ok=True)
    df = generate()
    df.to_csv(RAW_CSV, index=False)

    print(f"Saved: {RAW_CSV}")
    print(f"Shape: {df.shape} | Positive rate: {df['label'].mean():.3f}")

if __name__ == "__main__":
    main()
