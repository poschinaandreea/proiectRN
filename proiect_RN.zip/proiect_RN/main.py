# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
from pathlib import Path
import numpy as np
import joblib
import tensorflow as tf
import streamlit as st

from config.config import FEATURES, SCALER_PATH, MLP_MODEL_PATH, THRESHOLD

st.set_page_config(
    page_title="RN – Interfață Inferență",
    page_icon="🧠",
    layout="centered"
)

st.title("🧠 Interfață RN – Inferență (MLP)")
st.write("Introduce valorile numerice și apasă **Predict**. Aplicația folosește modelul antrenat din `models/trained_model.h5`.")

# Verificări fișiere
missing = []
if not Path(SCALER_PATH).exists():
    missing.append(f"Scaler lipsă: `{SCALER_PATH}` (rulează `python src/preprocessing/split_and_scale.py`)")

if not Path(MLP_MODEL_PATH).exists():
    missing.append(f"Model lipsă: `{MLP_MODEL_PATH}` (rulează `python src/neural_network/train_mlp.py`)")

if missing:
    st.error("Nu pot porni inferența până nu există fișierele necesare:")
    for m in missing:
        st.write("- " + m)
    st.stop()

@st.cache_resource
def load_assets():
    scaler = joblib.load(SCALER_PATH)
    model = tf.keras.models.load_model(MLP_MODEL_PATH)
    return scaler, model

scaler, model = load_assets()

st.subheader("📥 Date de intrare")
col1, col2 = st.columns(2)

# Valori default (ca exemplul tău)
defaults = {
    "avg_speed": 0.6,
    "stop_time": 35.0,
    "direction_changes": 10,
    "path_irregularity": 1.2,
    "time_of_day": 2,
    "distance": 20.0
}

inputs = {}

with col1:
    inputs["avg_speed"] = st.number_input("avg_speed", value=float(defaults["avg_speed"]), step=0.01)
    inputs["stop_time"] = st.number_input("stop_time", value=float(defaults["stop_time"]), step=0.1)
    inputs["direction_changes"] = st.number_input("direction_changes", value=int(defaults["direction_changes"]), step=1)

with col2:
    inputs["path_irregularity"] = st.number_input("path_irregularity", value=float(defaults["path_irregularity"]), step=0.01)
    inputs["time_of_day"] = st.number_input("time_of_day (0–23)", min_value=0, max_value=23, value=int(defaults["time_of_day"]), step=1)
    inputs["distance"] = st.number_input("distance", value=float(defaults["distance"]), step=0.1)

st.divider()

btn_col1, btn_col2 = st.columns([1, 1])
with btn_col1:
    do_predict = st.button("🚀 Predict", use_container_width=True)
with btn_col2:
    st.caption(f"Threshold curent: **{THRESHOLD:.2f}**")

if do_predict:
    # Construim vectorul în ordinea FEATURES
    x = np.array([[inputs[f] for f in FEATURES]], dtype=float)
    x_scaled = scaler.transform(x)

    prob = float(model.predict(x_scaled, verbose=0).ravel()[0])
    pred = 1 if prob >= THRESHOLD else 0

    st.subheader("✅ Rezultat")

    if pred == 1:
        st.error(f"Predicție: **SUSPECT (1)**")
    else:
        st.success(f"Predicție: **NORMAL (0)**")

    st.write(f"Probabilitate clasa 1: **{prob:.3f}**")
    st.progress(min(max(prob, 0.0), 1.0))

    with st.expander("Detalii (JSON)"):
        st.json({
            "inputs": inputs,
            "probability_class_1": prob,
            "threshold": THRESHOLD,
            "prediction": pred,
            "label": "SUSPECT (1)" if pred == 1 else "NORMAL (0)"
        })

st.caption("Sugestie pentru predare: fă screenshot după o predicție și salvează în `docs/screenshots/inference_real.png`.")
