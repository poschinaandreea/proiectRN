import numpy as np
import pandas as pd
import matplotlib
import joblib
import sklearn
import tensorflow as tf

print("NumPy:", np.__version__)
print("Pandas:", pd.__version__)
print("Matplotlib backend:", matplotlib.get_backend())
print("Joblib:", joblib.__version__)
print("Scikit-learn:", sklearn.__version__)
print("TensorFlow:", tf.__version__)
print("Totul este instalat corect!")
