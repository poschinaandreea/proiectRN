import tensorflow as tf

def main():
    print("TensorFlow version:", tf.__version__)
    devices = tf.config.list_physical_devices()
    print("Devices:", devices)

    # mini rețea + un pas de antrenare (ca test real)
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(2,)),
        tf.keras.layers.Dense(8, activation="relu"),
        tf.keras.layers.Dense(1, activation="sigmoid")
    ])

    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

    X = tf.constant([[0.0, 0.0],
                     [0.0, 1.0],
                     [1.0, 0.0],
                     [1.0, 1.0]], dtype=tf.float32)
    y = tf.constant([0, 1, 1, 0], dtype=tf.float32)  # XOR-ish (nu perfect cu 1 strat, dar testul e pentru runtime)

    history = model.fit(X, y, epochs=2, verbose=1)
    print("TensorFlow ruleaza OK. Ultimul loss:", history.history["loss"][-1])

if __name__ == "__main__":
    main()
