import matplotlib
matplotlib.use("TkAgg")

import matplotlib.pyplot as plt

plt.plot([1, 2, 3], [1, 4, 9])
plt.show()



import matplotlib
print(matplotlib.get_backend())
