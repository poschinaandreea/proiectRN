import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression

def main():
    X = np.array([[0.0], [1.0], [2.0], [3.0]])
    y = np.array([0, 0, 1, 1])

    model = LogisticRegression().fit(X, y)

    joblib.dump(model, "joblib_model_test.joblib")
    loaded = joblib.load("joblib_model_test.joblib")

    pred = loaded.predict([[1.5]])[0]
    print("joblib functioneaza corect. Predictie exemplu:", pred)

if __name__ == "__main__":
    main()
