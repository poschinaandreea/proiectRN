# Test curat pentru scikit-learn
# NU importa matplotlib

import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

def main():
    # Date simple
    X = np.array([
        [1.0, 10.0],
        [2.0, 20.0],
        [3.0, 30.0],
        [4.0, 40.0]
    ])
    y = np.array([0, 0, 1, 1])

    # Standardizare
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Model simplu
    model = LogisticRegression()
    model.fit(X_scaled, y)

    # Predicție
    y_pred = model.predict(X_scaled)

    acc = accuracy_score(y, y_pred)

    print("scikit-learn functioneaza corect")
    print("Accuracy:", acc)

if __name__ == "__main__":
    main()
