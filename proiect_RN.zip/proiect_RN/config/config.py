from pathlib import Path

# Reproducibilitate
RANDOM_SEED = 42

# Dataset
N_SAMPLES = 5000
TEST_SIZE = 0.20
VAL_SIZE = 0.20          # procent din (train+val) după primul split
LABEL_NOISE = 0.08       # flip probabilistic al etichetei

# Prag decizie (pentru inferenta MLP)
THRESHOLD = 0.5

# Root proiect (folderul proiectului)
ROOT = Path(__file__).resolve().parents[1]

# Directoare date
DATA_RAW_DIR = ROOT / "data" / "raw"
DATA_PROCESSED_DIR = ROOT / "data" / "processed"
DATA_TRAIN_DIR = ROOT / "data" / "train"
DATA_VAL_DIR = ROOT / "data" / "validation"
DATA_TEST_DIR = ROOT / "data" / "test"

# Directoare modele si rezultate
# Cerinta Etapa 5: modelul antrenat trebuie salvat in folderul "models/"
MODELS_DIR = ROOT / "models"
RESULTS_FIG_DIR = ROOT / "results" / "figures"

# Fisiere date
RAW_CSV = DATA_RAW_DIR / "dataset.csv"
PROCESSED_CSV = DATA_PROCESSED_DIR / "dataset_processed.csv"

# Fisiere modele
SCALER_PATH = MODELS_DIR / "scaler.joblib"
BASELINE_MODEL_PATH = MODELS_DIR / "baseline.joblib"

# Cerinta Etapa 5: model antrenat salvat in models/trained_model.h5
MLP_MODEL_PATH = MODELS_DIR / "trained_model.h5"

# Features
FEATURES = [
    "avg_speed",
    "stop_time",
    "direction_changes",
    "path_irregularity",
    "time_of_day",
    "distance",
]
LABEL_COL = "label"
