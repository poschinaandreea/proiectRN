import pandas as pd
import os
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
import joblib  # Utilizat pentru salvarea și încărcarea modelelor Python

# Definirea căilor (Paths)
PROCESSED_PATH = "Data/processed/"  # Calea către datele train/validation/test
MODEL_PATH = "models/"  # Calea unde va fi salvat modelul antrenat


def train_and_evaluate_model():
    print("--- Începe Antrenarea Modelului de Detectare a Suspiciunii ---")

    # 1. Încărcarea Datelor
    # Încărcăm setul de antrenare (Train) și setul de testare (Test)
    train_df = pd.read_csv(PROCESSED_PATH + "train/train.csv")
    test_df = pd.read_csv(PROCESSED_PATH + "test/test.csv")

    # Definim coloanele care sunt caracteristici (X) și coloana țintă (y)
    # Excludem 'timp' deoarece nu este relevant pentru clasificare
    features = ['durata_sec', 'miscare']
    target = 'label'

    X_train = train_df[features]  # Caracteristicile pentru antrenare
    y_train = train_df[target]  # Etichetele (Label) pentru antrenare

    X_test = test_df[features]  # Caracteristicile pentru evaluarea finală
    y_test = test_df[target]  # Etichetele reale pentru evaluarea finală

    # 2. Antrenarea Modelului
    print("Antrenarea Regresiei Logistice...")

    # Regresia Logistică este un algoritm excelent pentru clasificare binară (0 sau 1)
    model = LogisticRegression(random_state=42)

    # Funcția 'fit' antrenează modelul, învățând din X_train și y_train
    model.fit(X_train, y_train)

    print("Antrenare finalizată cu succes.")

    # 3. Evaluarea Modelului
    print("\n--- Evaluarea Performanței pe Setul de Test ---")

    # Facem predicții pe datele de test pe care modelul nu le-a văzut niciodată
    y_pred = model.predict(X_test)

    # Calculăm Acuratețea (procentul de predicții corecte)
    accuracy = accuracy_score(y_test, y_pred)

    print(f"Acuratețea pe setul de test: {accuracy * 100:.2f}%")
    print("\nRaport de Clasificare (detalii despre precizie, recall și F1-score):")
    print(classification_report(y_test, y_pred))

    # 4. Salvarea Modelului
    os.makedirs(MODEL_PATH, exist_ok=True)
    model_filename = os.path.join(MODEL_PATH, 'suspicion_detector_model.pkl')

    # joblib.dump salvează modelul pe disc într-un format binar
    joblib.dump(model, model_filename)

    print(f"\nModel salvat cu succes în: {model_filename}")


if __name__ == "__main__":
    train_and_evaluate_model()