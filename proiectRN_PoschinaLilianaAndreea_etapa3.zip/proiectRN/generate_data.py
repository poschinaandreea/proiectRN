import pandas as pd
import numpy as np
import os

def generate_dataset(rows=500):

    data = {
        "timp": np.arange(1, rows + 1),
        "durata_sec": np.random.uniform(1, 20, rows),
        "miscare": np.random.uniform(0, 1, rows),
    }

    df = pd.DataFrame(data)

    df["label"] = ((df["durata_sec"] > 10) & (df["miscare"] < 0.2)).astype(int)

    os.makedirs("data/raw", exist_ok=True)
    df.to_csv("data/raw/data_simulated.csv", index=False)

    print("Date generate cu succes!")

if __name__ == "__main__":
    generate_dataset()
